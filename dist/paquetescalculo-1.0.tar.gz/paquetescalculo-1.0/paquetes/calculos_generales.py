def sumar(op1, op2):
    print("El resultado es: ", op1 + op2)


def resta(op1, op2):
    print("La resta es: ", op1 - op2)

def multi(op1, op2):
    print("El resultado es: ", op1 * op2)


def divi(op1, op2):
    print("La division es: ", op1 / op2)


