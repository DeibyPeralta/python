def potencia(base, expo):
    print("El exponente es:  ", base**expo)

    print("Pontencia")